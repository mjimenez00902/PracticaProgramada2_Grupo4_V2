/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.fidelitas.java.practicaprogramada2;

/**
 *
 * @author hugob
 */
public class CuidadoPersonal extends ProductoBase {
    
    //atributos
    private String tipoCuidado;
    private String presentacion;

    //constructor
    public CuidadoPersonal(String tipoCuidado, String presentacion, String codigo, String nombre, double precio, int cantidadInventario) {
        super(codigo, nombre, precio, cantidadInventario);
        this.tipoCuidado = tipoCuidado;
        this.presentacion = presentacion;
    }
    
    //getter and setters

    public String getTipoCuidado() {
        return tipoCuidado;
    }

    public void setTipoCuidado(String tipoCuidado) {
        this.tipoCuidado = tipoCuidado;
    }

    public String getPresentacion() {
        return presentacion;
    }

    public void setPresentacion(String presentacion) {
        this.presentacion = presentacion;
    }
    
    @Override
    public double obtenerPrecioFinal() {
        return getPrecio();
}
    
     @Override
    public String toString() {
        return "CuidadoPersonal{"
                + "codigo=" + getCodigo()
                + ", nombre=" + getNombre()
                + ", precio=" + getPrecio()
                + ", cantidadInventario=" + getCantidadInventario()
                + ", tipoCuidado=" + tipoCuidado
                + ", presentacion=" + presentacion
                + '}';
    }
    
    
    
    
}
